"""Face. Two pages are seated: splash, then the bot panel.

The pages are index.html. They use the screenshots of the Mac shell.
The command catalog in unified-bar has no tokens, so GO does not dispatch a command.
It sends the line to the Heart through between/open.py.
"""

def on_line(text: str) -> str:
    from between.open import ask
    return ask(text)
