#!/usr/bin/env python3
"""Serve the two-page face. GO sends the line to the seated Heart.

The closed egg is already wired to its Heart: GET /heart and POST /ask.
The first successful unfurl (Heart up) writes fuse.json in the egg directory.
After that the shell and this Heart are one app: starting the face brings
the Heart runner and the shim back up if they are down, and keeps them up.
Fusion never opens the egg while the Heart is down.
"""
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EGG = ROOT.parent
FUSE = EGG / "fuse.json"
HEART_REL = "HEARTS/Qwen3-0.6B-Q8_0.gguf"
HEART_GGUF = EGG / "HEARTS" / "Qwen3-0.6B-Q8_0.gguf"
LLAMA = EGG / "llama-b11393" / "llama-server"
SHIM = EGG / "heart-shim.py"
SHIM_URL = "http://127.0.0.1:11434/"
RUNNER_PORT = 11435
SHIM_PORT = 11434

_lock = threading.Lock()
_last_start = {"runner": 0.0, "shim": 0.0}


def _fuse_record():
    return {
        "fused": True,
        "oneApp": True,
        "shell": "face",
        "heart": HEART_REL,
        "runner": "127.0.0.1:11435",
        "shim": "127.0.0.1:11434",
        "statement": "The shell and this Heart are one app.",
    }


def read_fuse():
    try:
        data = json.loads(FUSE.read_text(encoding="utf-8"))
    except Exception:
        return None
    if isinstance(data, dict) and data.get("fused") is True and data.get("heart") == HEART_REL:
        return data
    return None


def heart_up():
    up = False
    try:
        with urllib.request.urlopen(SHIM_URL, timeout=1) as resp:
            raw = resp.read()
            up = resp.status == 200
            try:
                payload = json.loads(raw.decode() or "{}")
                if isinstance(payload, dict) and "up" in payload:
                    up = bool(payload["up"])
            except Exception:
                pass
    except Exception:
        up = False
    return up


def _refresh_drawer():
    """Tell the shell to rescan so the fused tile shows up in this session."""
    runtime = os.environ.get("XDG_RUNTIME_DIR") or "/run/user/%s" % os.getuid()
    env = os.environ.copy()
    env["XDG_RUNTIME_DIR"] = runtime
    env.setdefault("DBUS_SESSION_BUS_ADDRESS", "unix:path=%s/bus" % runtime)
    try:
        subprocess.run(
            ["gdbus", "call", "--session",
             "--dest", "com.lomiri.Shell.Launcher",
             "--object-path", "/com/lomiri/Shell/Launcher",
             "--method", "com.lomiri.Shell.Launcher.Refresh"],
            env=env, timeout=3, check=False,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def install_launcher():
    """After unfurl, put the fused tile in the app drawer. No icon before fusion."""
    if not read_fuse():
        return
    tile = ROOT / "assets" / "tiles" / "yabowzr-256.png"
    if not tile.is_file():
        tile = ROOT / "assets" / "tiles" / "integrated.png"
    if not tile.is_file():
        return
    home = Path.home()
    data = tile.read_bytes()
    # The drawer paints Icon as an image path. A theme name stays blank.
    # suru/apps/256 is also where a named lookup finds a 256px tile.
    placed = []
    for rel in (
        ".local/share/icons/suru/apps/256/yabowzr.png",
        ".local/share/icons/hicolor/256x256/apps/yabowzr.png",
    ):
        icon = home / rel
        icon.parent.mkdir(parents=True, exist_ok=True)
        if not icon.is_file() or icon.read_bytes() != data:
            icon.write_bytes(data)
        placed.append(icon)
    apps = home / ".local" / "share" / "applications"
    apps.mkdir(parents=True, exist_ok=True)
    desktop = apps / "yabowzr.desktop"
    desktop.write_text(
        "[Desktop Entry]\n"
        "Name=ЯBOWZR\n"
        "Comment=ЯBOWZR shell\n"
        "Exec=/home/phablet/ubuntu-os-0.1.0-linux-arm64/face/start.sh\n"
        "Icon=%s\n"
        "Type=Application\n"
        "Terminal=false\n"
        "X-Lomiri-Touch=true\n"
        "X-Lomiri-Single-Instance=true\n" % placed[0]
    )
    _refresh_drawer()




def write_fuse():
    """Record fusion once. Refuses while the Heart is down. Does not touch the gguf."""
    existing = read_fuse()
    if existing:
        install_launcher()
        return existing
    if not heart_up():
        return None
    record = _fuse_record()
    raw = json.dumps(record, indent=2).encode() + b"\n"
    tmp = FUSE.with_name("fuse.json.tmp")
    tmp.write_bytes(raw)
    os.replace(tmp, FUSE)
    install_launcher()
    return record


def _port_open(port):
    import socket
    sock = socket.socket()
    sock.settimeout(0.3)
    try:
        sock.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        sock.close()


def _cmdline_has(fragment):
    proc = Path("/proc")
    try:
        names = list(proc.iterdir())
    except Exception:
        return False
    for entry in names:
        if not entry.name.isdigit():
            continue
        try:
            cmd = (entry / "cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", "ignore")
        except Exception:
            continue
        if fragment in cmd:
            return True
    return False


def _spawn(argv, log_name):
    log_path = Path("/tmp") / log_name
    log = open(log_path, "ab", buffering=0)
    subprocess.Popen(
        ["setsid", "--fork", *argv],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        cwd=str(EGG),
    )


def ensure_heart():
    """If fused, start the Heart runner and the shim when they are down. Never downloads weights."""
    if read_fuse() is None:
        return
    now = time.time()
    with _lock:
        runner_up = _port_open(RUNNER_PORT) or _cmdline_has("llama-server")
        if (not runner_up) and LLAMA.is_file() and HEART_GGUF.is_file() and now - _last_start["runner"] > 5:
            _last_start["runner"] = now
            _spawn(
                [
                    str(LLAMA),
                    "-m", str(HEART_GGUF),
                    "--host", "127.0.0.1",
                    "--port", str(RUNNER_PORT),
                    "-c", "512",
                    "-t", "4",
                    "--no-warmup",
                ],
                "yabowzr-llama.log",
            )
        shim_up = _port_open(SHIM_PORT) or _cmdline_has("heart-shim.py")
        if (not shim_up) and SHIM.is_file() and now - _last_start["shim"] > 5:
            _last_start["shim"] = now
            _spawn([sys.executable, str(SHIM)], "yabowzr-shim.log")


def _keeper():
    while True:
        try:
            ensure_heart()
        except Exception:
            pass
        time.sleep(2)


class Face(BaseHTTPRequestHandler):
    def do_GET(self):
        path_only = self.path.split("?", 1)[0]
        if path_only == "/heart":
            self._json(200, {"up": heart_up()})
            return
        if path_only == "/fuse":
            record = read_fuse()
            if record:
                self._json(200, record)
            else:
                self._json(200, {"fused": False})
            return
        rel = "index.html" if path_only in ("/", "") else path_only.lstrip("/")
        path = (ROOT / rel).resolve()
        if not str(path).startswith(str(ROOT)) or not path.is_file():
            self.send_error(404)
            return
        kind = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".png": "image/png",
        }.get(path.suffix, "application/octet-stream")
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    LANE = {
        "https://raw.githubusercontent.com/rizalward/rizal.info/main/rbowzr/appcast.json",
        "https://rizal.info/rbowzr/appcast.json",
        "http://rizal.pw/rbowzr/appcast.json",
        "https://raw.githubusercontent.com/rizalward/rizal.info/main/rbowzr/linux/linuxeum-darwineus.json",
        "https://rizal.info/rbowzr/linux/linuxeum-darwineus.json",
        "http://rizal.pw/rbowzr/linux/linuxeum-darwineus.json",
    }

    def _json(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            self.send_error(400)
            return
        path_only = self.path.split("?", 1)[0]
        if path_only == "/fuse":
            record = write_fuse()
            if record is None:
                self._json(503, {"fused": False, "up": False})
                return
            ensure_heart()
            self._json(200, record)
            return
        if path_only == "/open":
            url = str(data.get("url", "")).strip()
            if not url:
                self._json(400, {"error": "Empty address."})
                return
            if url.startswith("//"):
                url = "https:" + url
            if re.match(r"^[^:/\\s]+\.[A-Za-z]{2,}(?::\d+)?(?:/|$)", url):
                url = "https://" + url
            scheme = (url.split(":", 1)[0].lower() if ":" in url else "file")
            supported = scheme in {"http", "https", "ftp", "file", "content", "rzl", "yabowzr", "rbowzr", "mailto"} or url.startswith(("/", "~/"))
            if not supported:
                self._json(200, {"reply": "Address rejected · unsupported scheme: " + scheme})
                return
            if url in self.LANE:
                try:
                    with urllib.request.urlopen(url, timeout=20) as resp:
                        resp.read(400)
                        code = resp.status
                    self._json(200, {"reply": "ONLINE lane " + str(code) + " " + url, "address": url, "kind": "network", "fetched": True})
                except Exception as exc:
                    self._json(200, {"reply": "Address accepted, but the lane did not answer. " + str(exc), "address": url, "kind": "network", "fetched": False})
                return
            kind = "network" if scheme in {"http", "https", "ftp"} else ("local-file" if scheme in {"file", "content"} or url.startswith(("/", "~/")) else "local-address")
            self._json(200, {"reply": "Address accepted · " + kind + " · " + url + " · no fetch", "address": url, "kind": kind, "fetched": False})
            return
        if path_only != "/ask":
            self.send_error(404)
            return
        text = data.get("text", "")
        try:
            from between.open import ask
            reply = ask(text)
            body = json.dumps({"reply": reply}).encode()
            code = 200
        except Exception as exc:
            body = json.dumps({"error": str(exc)}).encode()
            code = 500
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    sys.path.insert(0, str(EGG))
    ensure_heart()
    install_launcher()
    threading.Thread(target=_keeper, name="heart-keeper", daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1", 8765), Face).serve_forever()
