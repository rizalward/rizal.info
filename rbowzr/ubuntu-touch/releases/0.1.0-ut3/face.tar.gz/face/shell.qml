import QtQuick 2.9
import QtQuick.Window 2.2
import QtWebEngine 1.10

Window {
    id: shell
    visible: true
    width: Screen.width
    height: Screen.height
    title: "ЯBOWZR"
    flags: Qt.Window | Qt.FramelessWindowHint
    color: "#111111"

    WebEngineView {
        anchors.fill: parent
        url: "http://127.0.0.1:8765/mobile.html"
        profile: WebEngineProfile {
            storageName: "yabowzr-shell"
            offTheRecord: true
        }
    }
}
