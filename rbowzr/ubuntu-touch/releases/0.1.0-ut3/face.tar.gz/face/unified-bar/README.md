# unified-bar egg 1.1.0 — THE UNIFIED SMART COMMAND SEARCH ADDRESS MANUAL BAR (public catalog)
Payload: BASE-COMMANDS.json (public, scrubbed: no personal or classroom commands). The scout composer (osCommandDispatch) and the native
ЯFRAME bar (RBarRoute.osCommandVerbs, egg-aware builds) read it. A Decider build loads its own MACHINE-MIND seed natively instead.
Overlay: ЯBOWZR ShellResources/ · ЯBOT RBOWSER-web.bundle/rbowzr-classic/. Data only — never carries roster/profile files.
